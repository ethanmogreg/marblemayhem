﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float ballSpeed;
    public bool sprinting = false;
    public GameObject powerupIndicator;
    // Start is called before the first frame update
    void Start()
    {

    }



    // Update is called once per frame
    void Update()
    {
        powerupIndicator.transform.position = transform.position + new Vector3(0, -0.5f, 0);
        if (sprinting)
        {
            powerupIndicator.SetActive(true);
            ballSpeed = 300f;
        }

        if (!sprinting)
        {
            powerupIndicator.SetActive(false);
            ballSpeed = 150f;
        }


        float xSpeed = Input.GetAxis("Vertical");
        float ySpeed = Input.GetAxis("Horizontal");
        Rigidbody body = GetComponent<Rigidbody>();
        body.AddForce(new UnityEngine.Vector3(-xSpeed, 0, ySpeed) * ballSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.LeftShift))
        {
            sprinting = true;
        }

        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            sprinting = false;
        }

        //player goes faster if they press left shift.
    }

}
