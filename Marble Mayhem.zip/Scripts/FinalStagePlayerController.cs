﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalStagePlayerController : MonoBehaviour
{
    public float ballSpeed;
    public bool sprinting = false;
    public GameObject powerupIndicator;
    private float powerupStrength = 300;
    public GameObject powerupIndicator2;
    public bool hasPowerup;
    private AudioSource playerAudio;
    public AudioClip powerupSound;
    

    // Start is called before the first frame update
    void Start()
    {
        powerupSound = Resources.Load<AudioClip>("clockSound");
    }



    // Update is called once per frame
    void Update()
    {
        powerupIndicator.transform.position = transform.position + new Vector3(0, -0.5f, 0);
        if (sprinting)
        {
            powerupIndicator.SetActive(true);
            ballSpeed = 300f;
        }

        if (!sprinting)
        {
            powerupIndicator.SetActive(false);
            ballSpeed = 150f;
        }

        //This script exists because I needed to adjust the controls for the final stage.

        float xSpeed = Input.GetAxis("Horizontal");
        float ySpeed = Input.GetAxis("Vertical");
        Rigidbody body = GetComponent<Rigidbody>();
        body.AddForce(new UnityEngine.Vector3(xSpeed, 0, ySpeed) * ballSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.LeftShift))
        {
            sprinting = true;
        }

        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            sprinting = false;
        }

        // player goes faster if they hold left shift.

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Powerup"))
        {
            hasPowerup = true;
            powerupIndicator2.gameObject.SetActive(true); 
            Destroy(other.gameObject);
            if (other.CompareTag("Powerup"))
            {
                //playerAudio.PlayOneShot(powerupSound); couldn't get this to work.
                hasPowerup = true;
                Destroy(other.gameObject);
                StartCoroutine(PowerupCountdownRoutine());

                IEnumerator PowerupCountdownRoutine()
                {
                    yield return new WaitForSeconds(7);
                    hasPowerup = false;
                    powerupIndicator2.gameObject.SetActive(false);
                }
            }
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy") && hasPowerup)
        {
            Rigidbody enemyRigidbody = collision.gameObject.GetComponent<Rigidbody>();
            Vector3 awayFromPlayer = (collision.gameObject.transform.position - transform.position);
            Debug.Log("Player has collided with " + collision.gameObject + " with powerup set to " + hasPowerup);
            enemyRigidbody.AddForce(awayFromPlayer * powerupStrength, ForceMode.Impulse);
        }

    }
}
