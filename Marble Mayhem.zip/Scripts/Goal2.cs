﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Goal2 : MonoBehaviour
{
    public Text winText;
    private bool hasReachedGoal = false;
    // Start is called before the first frame update
    void Start()
    {
        winText.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.anyKey && hasReachedGoal)
        {
            Time.timeScale = 1;
            SceneManager.LoadScene("Stage2");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            winText.text = "You beat Stage 2! Press any key to continue.";
            Time.timeScale = 0.00001f;
            hasReachedGoal = true;

        }
    }
}
