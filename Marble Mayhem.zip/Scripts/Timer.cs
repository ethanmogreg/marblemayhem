﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    public static float currentTime = 0f;
    public float startingTime = 60f;

    [SerializeField] Text timerText;

    // Start is called before the first frame update
    void Start()
    {
        currentTime = startingTime;
    }

    // Update is called once per frame
    void Update()
    {
        currentTime -= 1 *Time.deltaTime;
        timerText.text = currentTime.ToString("0");

   
        //timer will never go below 0.
        if (currentTime <= 0)
        {
            currentTime = 0;
        }
        //timer reaches 0, player gets a game over.
        if (currentTime == 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
}
