﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Goal : MonoBehaviour
{
    public Text winText;
    private bool hasReachedGoal = false;
    private AudioSource goalAudio;
    public AudioClip goalSound;
    // Start is called before the first frame update
    void Start()
    {
        winText.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        //tried a few different methods for seeing if I can get sound effects to play for certain things. I wasn't able to get it to work.
      //if (hasReachedGoal)
      //{
      //    goalAudio.PlayOneShot(goalSound, 1.0f);
      //}

        if (Input.anyKey && hasReachedGoal)
        {
            Time.timeScale = 1;
            SceneManager.LoadScene("Stage1");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            winText.text = "You beat Stage 1! Press any key to continue.";
            Time.timeScale = 0.00001f;
            hasReachedGoal = true;
            
        }
    }
}
