using UnityEngine;
using System.Collections;


public class Clock : MonoBehaviour {

    public GameObject Player;
    public static AudioClip clockSound;
    public static AudioClip goalSound;
    static AudioSource audioSrc;
    void Start()
    {

    }

    void Update()
    {
        //clock rotates.
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);


    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Timer.currentTime += 5f;
            Destroy(gameObject);

        }



    }

}
